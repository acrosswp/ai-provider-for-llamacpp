<?php
/**
 * PSR-4 autoloader for the AI Provider for llama.cpp package.
 *
 * @since 0.0.1
 *
 * @package WordPress\LlamaCppAiProvider
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	return;
}

spl_autoload_register(
	static function ( string $class_name ): void {
		$prefix   = 'WordPress\\LlamaCppAiProvider\\';
		$base_dir = __DIR__ . '/';

		$len = strlen( $prefix );

		if ( strncmp( $class_name, $prefix, $len ) !== 0 ) {
			return;
		}

		$relative_class = substr( $class_name, $len );
		$file           = $base_dir . str_replace( '\\', '/', $relative_class ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);
